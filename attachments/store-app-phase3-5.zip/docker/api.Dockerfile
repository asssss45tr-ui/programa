FROM node:20-alpine AS build
WORKDIR /app

COPY package*.json ./
COPY apps/api/package.json apps/api/
COPY apps/web/package.json apps/web/
COPY packages/shared/package.json packages/shared/

RUN npm install --no-audit --no-fund

COPY . .
RUN npm run build:shared && npm run build:api && npm run build:web
RUN cd apps/api && npx prisma generate

FROM node:20-alpine
WORKDIR /app
COPY --from=build /app ./
EXPOSE 3000
CMD ["node", "apps/api/dist/main.js"]
