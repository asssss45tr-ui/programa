FROM node:20-alpine AS build
WORKDIR /app

COPY . .
RUN npm install --no-audit --no-fund && npm run build:web

FROM nginx:alpine
COPY docker/nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/apps/web/dist /usr/share/nginx/html
EXPOSE 80
