-- اجرای خودکار در اولین راه‌اندازی کانتینر PostgreSQL
CREATE EXTENSION IF NOT EXISTS pg_trgm;
