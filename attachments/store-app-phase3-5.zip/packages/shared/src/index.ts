/**
 * کدهای دسترسی سیستم — منبع واحد برای فرانت و بک
 */
export const PERMISSION_CODES = [
  'users.manage',
  'products.view',
  'products.manage',
  'sales.view',
  'sales.create',
  'sales.cancel',
  'sales.return',
  'customers.view',
  'customers.manage',
  'purchases.view',
  'purchases.create',
  'purchases.cancel',
  'inventory.view',
  'inventory.adjust',
  'inventory.transfer',
  'suppliers.view',
  'suppliers.manage',
  'payments.manage',
  'reports.view',
  'dashboard.view',
  'settings.manage',
  'audit.view',
  'backup.manage',
] as const;

export type PermissionCode = (typeof PERMISSION_CODES)[number];

export const ROLE_NAMES = {
  ADMIN: 'admin',
  SELLER: 'seller',
  WAREHOUSE_KEEPER: 'warehouse_keeper',
} as const;

/**
 * نرمال‌سازی متن فارسی برای جستجو:
 * یکدست‌سازی ی/ک عربی، حذف اعراب و نیم‌فاصله، تبدیل ارقام فارسی/عربی به لاتین
 */
export function normalizeFa(input: string): string {
  return input
    .trim()
    .replace(/\u064A/g, '\u06CC') // ي -> ی
    .replace(/\u0649/g, '\u06CC') // ى -> ی
    .replace(/\u0643/g, '\u06A9') // ك -> ک
    .replace(/[\u064B-\u0652]/g, '') // حذف اعراب
    .replace(/[\u200c\u200f\u200e]/g, ' ') // نیم‌فاصله و نشانه‌های جهت
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) & 0xf))
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) & 0xf))
    .replace(/\s+/g, ' ')
    .toLowerCase();
}
