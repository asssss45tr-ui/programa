/**
 * Seed اولیه دیتابیس:
 * - نقش‌ها (مدیر، فروشنده، انباردار)
 * - تمام permissionها
 * - تخصیص دسترسی هر نقش طبق ماتریس فاز 0
 * - سه کاربر آزمایشی
 * - انبار پیش‌فرض، واحد پیش‌فرض، تنظیمات، شمارنده شماره فاکتور
 */
import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

const PERMISSIONS: { code: string; nameFa: string; module: string }[] = [
  { code: 'users.manage', nameFa: 'مدیریت کاربران', module: 'کاربران' },
  { code: 'products.view', nameFa: 'مشاهده کالا', module: 'کالا' },
  { code: 'products.manage', nameFa: 'ثبت و ویرایش کالا', module: 'کالا' },
  { code: 'sales.view', nameFa: 'مشاهده فروش', module: 'فروش' },
  { code: 'sales.create', nameFa: 'ثبت فروش', module: 'فروش' },
  { code: 'sales.cancel', nameFa: 'لغو فاکتور فروش', module: 'فروش' },
  { code: 'sales.return', nameFa: 'برگشت فروش', module: 'فروش' },
  { code: 'customers.view', nameFa: 'مشاهده مشتریان', module: 'اشخاص' },
  { code: 'customers.manage', nameFa: 'مدیریت مشتریان', module: 'اشخاص' },
  { code: 'purchases.view', nameFa: 'مشاهده خرید', module: 'خرید' },
  { code: 'purchases.create', nameFa: 'ثبت خرید', module: 'خرید' },
  { code: 'purchases.cancel', nameFa: 'لغو فاکتور خرید', module: 'خرید' },
  { code: 'inventory.view', nameFa: 'مشاهده موجودی', module: 'انبار' },
  { code: 'inventory.adjust', nameFa: 'اصلاح موجودی', module: 'انبار' },
  { code: 'inventory.transfer', nameFa: 'انتقال بین انبار', module: 'انبار' },
  { code: 'suppliers.view', nameFa: 'مشاهده تأمین‌کنندگان', module: 'اشخاص' },
  { code: 'suppliers.manage', nameFa: 'مدیریت تأمین‌کنندگان', module: 'اشخاص' },
  { code: 'payments.manage', nameFa: 'ثبت پرداخت و دریافت', module: 'مالی' },
  { code: 'reports.view', nameFa: 'مشاهده گزارش‌ها', module: 'گزارش' },
  { code: 'dashboard.view', nameFa: 'مشاهده داشبورد', module: 'گزارش' },
  { code: 'settings.manage', nameFa: 'مدیریت تنظیمات', module: 'سیستم' },
  { code: 'audit.view', nameFa: 'مشاهده لاگ عملیات', module: 'سیستم' },
  { code: 'backup.manage', nameFa: 'پشتیبان‌گیری و بازیابی', module: 'سیستم' },
];

const ALL = PERMISSIONS.map((p) => p.code);

const SELLER = [
  'products.view', 'sales.view', 'sales.create', 'sales.return',
  'customers.view', 'customers.manage', 'payments.manage', 'reports.view', 'dashboard.view',
];

const WAREHOUSE = [
  'products.view', 'products.manage', 'purchases.view', 'purchases.create', 'purchases.cancel',
  'inventory.view', 'inventory.adjust', 'inventory.transfer',
  'suppliers.view', 'suppliers.manage', 'payments.manage', 'reports.view', 'dashboard.view',
];

async function main() {
  console.log('— Seed شروع شد —');

  // نقش‌ها
  const rolesData = [
    { name: 'admin', nameFa: 'مدیر' },
    { name: 'seller', nameFa: 'فروشنده' },
    { name: 'warehouse_keeper', nameFa: 'انباردار' },
  ];
  for (const r of rolesData) {
    await prisma.role.upsert({ where: { name: r.name }, update: { nameFa: r.nameFa }, create: { ...r, isSystem: true } });
  }
  const adminRole = await prisma.role.findUniqueOrThrow({ where: { name: 'admin' } });
  const sellerRole = await prisma.role.findUniqueOrThrow({ where: { name: 'seller' } });
  const warehouseRole = await prisma.role.findUniqueOrThrow({ where: { name: 'warehouse_keeper' } });

  // دسترسی‌ها
  for (const p of PERMISSIONS) {
    await prisma.permission.upsert({ where: { code: p.code }, update: { nameFa: p.nameFa, module: p.module }, create: p });
  }
  const perms = await prisma.permission.findMany();
  const permId = new Map(perms.map((p) => [p.code, p.id]));

  // تخصیص دسترسی نقش‌ها
  const assignments: [number, string[]][] = [
    [adminRole.id, ALL],
    [sellerRole.id, SELLER],
    [warehouseRole.id, WAREHOUSE],
  ];
  for (const [roleId, codes] of assignments) {
    await prisma.rolePermission.deleteMany({ where: { roleId } });
    await prisma.rolePermission.createMany({
      data: codes.map((code) => ({ roleId, permissionId: permId.get(code)! })),
    });
  }

  // کاربران آزمایشی
  const users = [
    { username: 'admin', fullName: 'مدیر سیستم', password: 'admin123', roleId: adminRole.id },
    { username: 'seller', fullName: 'فروشنده نمونه', password: 'seller123', roleId: sellerRole.id },
    { username: 'warehouse', fullName: 'انباردار نمونه', password: 'ware123', roleId: warehouseRole.id },
  ];
  for (const u of users) {
    await prisma.user.upsert({
      where: { username: u.username },
      update: { roleId: u.roleId },
      create: {
        username: u.username,
        fullName: u.fullName,
        passwordHash: await argon2.hash(u.password),
        roleId: u.roleId,
      },
    });
  }

  // انبار پیش‌فرض و واحد
  await prisma.warehouse.upsert({
    where: { name: 'انبار اصلی' },
    update: {},
    create: { name: 'انبار اصلی', code: 'WH1', isDefault: true },
  });
  await prisma.unit.upsert({ where: { name: 'عدد' }, update: {}, create: { name: 'عدد' } });
  await prisma.unit.upsert({ where: { name: 'کارتن' }, update: {}, create: { name: 'کارتن' } });
  await prisma.unit.upsert({ where: { name: 'کیلوگرم' }, update: {}, create: { name: 'کیلوگرم' } });

  // تنظیمات
  const settings: [string, unknown][] = [
    ['store_name', { value: 'فروشگاه من' }],
    ['tax_enabled', { value: false }],
    ['tax_rate', { value: 9 }],
    ['auto_product_code', { value: true }],
    ['default_warehouse_id', { value: 1 }],
    ['allow_negative_stock', { value: false }],
  ];
  for (const [key, value] of settings) {
    await prisma.setting.upsert({ where: { key }, update: { value: value as object }, create: { key, value: value as object } });
  }

  // شمارنده شماره فاکتور
  for (const s of [
    { docType: 'INV', prefix: 'INV-' },
    { docType: 'PUR', prefix: 'PUR-' },
  ]) {
    await prisma.numberSequence.upsert({ where: { docType: s.docType }, update: {}, create: { ...s, currentValue: 0, padding: 6 } });
  }

  console.log('— Seed کامل شد —');
  console.log('کاربران آزمایشی: admin/admin123 ، seller/seller123 ، warehouse/ware123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
