import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';

/**
 * فیلتر خطای سراسری:
 * خروجی همه خطاها با ساختار یکسان { code, message_fa, details } است.
 */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger('Exceptions');

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let code = 'INTERNAL_ERROR';
    let messageFa = 'خطای غیرمنتظره سرور رخ داد.';
    let details: unknown = undefined;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const body = exception.getResponse();
      if (typeof body === 'string') {
        messageFa = body;
      } else if (typeof body === 'object' && body !== null) {
        const b = body as Record<string, unknown>;
        code = (b.code as string) || exception.name || code;
        messageFa =
          (b.message_fa as string) ||
          (Array.isArray(b.message) ? b.message.join('، ') : (b.message as string)) ||
          messageFa;
        details = b.details;
      }
    } else if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      const mapped = mapPrismaError(exception);
      status = mapped.status;
      code = mapped.code;
      messageFa = mapped.messageFa;
      details = exception.meta;
    }

    if (status >= 500) {
      this.logger.error(
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    res.status(status).json({ code, message_fa: messageFa, details });
  }
}

function mapPrismaError(e: Prisma.PrismaClientKnownRequestError): {
  status: number;
  code: string;
  messageFa: string;
} {
  switch (e.code) {
    case 'P2002':
      return {
        status: HttpStatus.CONFLICT,
        code: 'DUPLICATE_VALUE',
        messageFa: 'مقدار تکراری — این مقدار قبلاً ثبت شده است.',
      };
    case 'P2025':
      return {
        status: HttpStatus.NOT_FOUND,
        code: 'NOT_FOUND',
        messageFa: 'مورد مورد نظر یافت نشد.',
      };
    case 'P2003':
      return {
        status: HttpStatus.CONFLICT,
        code: 'FOREIGN_KEY_CONSTRAINT',
        messageFa: 'این مورد به رکورد دیگری وابسته است و قابل تغییر نیست.',
      };
    default:
      return {
        status: HttpStatus.INTERNAL_SERVER_ERROR,
        code: 'DATABASE_ERROR',
        messageFa: 'خطای پایگاه داده رخ داد.',
      };
  }
}
