import { SetMetadata } from '@nestjs/common';

/** Endpoint عمومی (بدون احراز هویت) */
export const Public = () => SetMetadata('is_public', true);
