import { SetMetadata } from '@nestjs/common';

export const PERMISSIONS_KEY = 'required_permissions';

/** دکوراتور تعیین دسترسی(های) مورد نیاز Endpoint — همه باید برقرار باشند */
export const RequirePermissions = (...perms: string[]) =>
  SetMetadata(PERMISSIONS_KEY, perms);
