import { Injectable, CanActivate, ExecutionContext, ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.module';
import { PERMISSIONS_KEY } from './permissions.decorator';

export interface JwtPayload {
  sub: string;
  username: string;
  roleId: number;
  roleName: string;
}

/**
 * گارد سراسری: احراز هویت JWT + کنترل دسترسی مبتنی بر permission
 * Endpointهای عمومی با @Public() مشخص می‌شوند.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private jwt: JwtService,
    private reflector: Reflector,
    private prisma: PrismaService,
  ) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>('is_public', [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (isPublic) return true;

    const req = ctx.switchToHttp().getRequest();
    const header = req.headers['authorization'] || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) throw new UnauthorizedException('ابتدا وارد حساب خود شوید.');

    let payload: JwtPayload;
    try {
      payload = await this.jwt.verifyAsync<JwtPayload>(token);
    } catch {
      throw new UnauthorizedException('نشست منقضی شده است. دوباره وارد شوید.');
    }

    // کاربر باید فعال باشد
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
      include: { role: { include: { rolePermission: { include: { permission: true } } } } },
    });
    if (!user || !user.isActive) {
      throw new UnauthorizedException('حساب کاربری غیرفعال است.');
    }

    req.user = {
      sub: user.id,
      username: user.username,
      roleId: user.roleId,
      roleName: user.role.name,
      permissions: user.role.rolePermission.map((rp) => rp.permission.code),
    };

    // کنترل دسترسی سمت بک‌اند
    const required = this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (required?.length) {
      const perms: string[] = req.user.permissions;
      const missing = required.filter((p) => !perms.includes(p));
      if (missing.length) {
        throw new ForbiddenException('شما به این بخش دسترسی ندارید.');
      }
    }
    return true;
  }
}
