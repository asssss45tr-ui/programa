import { Request } from 'express';

/** استخراج کاربر از درخواست (پرشده توسط JwtAuthGuard) */
export interface RequestUser {
  sub: string;       // user id
  username: string;
  roleId: number;
  roleName: string;
  permissions: string[];
}

declare module 'express' {
  interface Request {
    user?: RequestUser;
  }
}

export function getRequestUser(req: Request): RequestUser {
  if (!req.user) throw new Error('کاربر احراز هویت نشده است.');
  return req.user;
}
