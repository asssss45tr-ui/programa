import 'reflect-metadata';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { Logger } from 'nestjs-pino';
import cookieParser from 'cookie-parser';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.set('trust proxy', true);

  const logger = app.get(Logger);
  app.useLogger(logger);

  // حداکثر اندازه بسته (برای بارگذاری تصویر کالا)
  app.useBodyParser('json', { limit: '10mb' });

  app.use(cookieParser());

  // همه مسیرها با پیشوند api/ و نسخه v1 سرو می‌شوند: /api/v1/...
  app.setGlobalPrefix('api');

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,          // هر ویژگی اضافی در DTO حذف می‌شود
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  // CORS برای توسعه فرانت‌اند
  app.enableCors({
    origin: true,
    credentials: true,
  });

  await app.listen(process.env.PORT || 3000, '0.0.0.0');
  console.log(`API running on http://localhost:${process.env.PORT || 3000}/api/v1 (health: /api/v1/health)`);
}

bootstrap().catch((e) => {
  console.error(e);
  process.exit(1);
});
