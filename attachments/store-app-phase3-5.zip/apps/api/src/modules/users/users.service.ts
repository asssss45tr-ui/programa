import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '../../prisma/prisma.module';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  list() {
    return this.prisma.user.findMany({
      select: {
        id: true, username: true, fullName: true, phone: true,
        isActive: true, lastLoginAt: true, createdAt: true,
        role: { select: { id: true, name: true, nameFa: true } },
      },
      orderBy: { createdAt: 'asc' },
    });
  }

  async create(dto: {
    username: string; fullName: string; password: string;
    roleId: number; phone?: string;
  }, actorId: string) {
    const exists = await this.prisma.user.findUnique({ where: { username: dto.username } });
    if (exists) throw new BadRequestException('این نام کاربری قبلاً ثبت شده است.');
    const user = await this.prisma.user.create({
      data: {
        username: dto.username,
        fullName: dto.fullName,
        passwordHash: await argon2.hash(dto.password),
        roleId: dto.roleId,
        phone: dto.phone,
      },
      select: { id: true, username: true, fullName: true, roleId: true, isActive: true },
    });
    await this.prisma.auditLog.create({
      data: {
        userId: actorId, action: 'USER_CREATE',
        entityType: 'user', entityId: user.id, afterData: { username: user.username },
      },
    });
    return user;
  }

  async update(id: string, dto: {
    fullName?: string; roleId?: number; phone?: string; isActive?: boolean; password?: string;
  }, actorId: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    const data: Record<string, unknown> = { ...dto };
    delete data.password;
    if (dto.password) {
      data.passwordHash = await argon2.hash(dto.password);
    }
    const updated = await this.prisma.user.update({
      where: { id },
      data,
      select: { id: true, username: true, fullName: true, roleId: true, isActive: true, phone: true },
    });
    await this.prisma.auditLog.create({
      data: {
        userId: actorId, action: 'USER_UPDATE', entityType: 'user', entityId: id,
        beforeData: { fullName: user.fullName, roleId: user.roleId, isActive: user.isActive },
        afterData: { fullName: dto.fullName, roleId: dto.roleId, isActive: dto.isActive },
      },
    });
    return updated;
  }

  /** حذف واقعی انجام نمی‌شود — فقط غیرفعال‌سازی */
  async deactivate(id: string, actorId: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    if (user.id === actorId) throw new BadRequestException('حساب خودتان را نمی‌توانید غیرفعال کنید.');
    await this.prisma.user.update({ where: { id }, data: { isActive: false } });
    await this.prisma.refreshToken.updateMany({ where: { userId: id }, data: { revokedAt: new Date() } });
    await this.prisma.auditLog.create({
      data: { userId: actorId, action: 'USER_DEACTIVATE', entityType: 'user', entityId: id },
    });
    return { ok: true };
  }
}
