import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post } from '@nestjs/common';
import { IsBoolean, IsInt, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { UsersService } from './users.service';
import { RequirePermissions } from '../../common/permissions.decorator';
import { getRequestUser } from '../../common/request-user';
import { User } from '@prisma/client';
import { Req } from '@nestjs/common';

export class CreateUserDto {
  @IsString() @MinLength(3) @MaxLength(50) username!: string;
  @IsString() @MinLength(2) @MaxLength(120) fullName!: string;
  @IsString() @MinLength(6) @MaxLength(100) password!: string;
  @IsInt() roleId!: number;
  @IsOptional() @IsString() @MaxLength(20) phone?: string;
}

export class UpdateUserDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(120) fullName?: string;
  @IsOptional() @IsInt() roleId?: number;
  @IsOptional() @IsString() @MaxLength(20) phone?: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
  @IsOptional() @IsString() @MinLength(6) @MaxLength(100) password?: string;
}

@Controller('users')
export class UsersController {
  constructor(private users: UsersService) {}

  @Get()
  @RequirePermissions('users.manage')
  list() {
    return this.users.list();
  }

  @Post()
  @RequirePermissions('users.manage')
  create(@Body() dto: CreateUserDto, @Req() req: Request & { user: { sub: string } }) {
    return this.users.create(dto, req.user.sub);
  }

  @Patch(':id')
  @RequirePermissions('users.manage')
  update(
    @Param('id') id: string,
    @Body() dto: UpdateUserDto,
    @Req() req: Request & { user: { sub: string } },
  ) {
    return this.users.update(id, dto, req.user.sub);
  }

  @Delete(':id')
  @RequirePermissions('users.manage')
  deactivate(@Param('id') id: string, @Req() req: Request & { user: { sub: string } }) {
    return this.users.deactivate(id, req.user.sub);
  }
}
