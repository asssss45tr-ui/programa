import { BadRequestException, Body, Controller, Delete, Get, Param, Patch, Post, Query, Req } from '@nestjs/common';
import { Request } from 'express';
import { ProductsService } from './products.service';
import { AddBarcodeDto, CatalogItemDto, CreateProductDto, UpdateProductDto } from './products.dto';
import { RequirePermissions } from '../../common/permissions.decorator';
import { getRequestUser } from '../../common/request-user';
import { PrismaService } from '../../prisma/prisma.module';

function parseId(id: string): bigint {
  if (!/^\d+$/.test(id)) throw new BadRequestException('شناسه نامعتبر است.');
  return BigInt(id);
}

@Controller('products')
export class ProductsController {
  constructor(private service: ProductsService) {}

  /** شناسایی سه‌روشی کالا: بارکد / کد کالا / نام */
  @Get('lookup')
  @RequirePermissions('products.view')
  lookup(@Query('term') term?: string) {
    return this.service.lookup(term ?? '');
  }

  @Get()
  @RequirePermissions('products.view')
  list(@Query('q') q?: string, @Query('page') page?: string, @Query('limit') limit?: string) {
    return this.service.list({
      q,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined,
    });
  }

  @Get(':id')
  @RequirePermissions('products.view')
  get(@Param('id') id: string) {
    return this.service.get(parseId(id));
  }

  @Post()
  @RequirePermissions('products.manage')
  create(@Body() dto: CreateProductDto, @Req() req: Request) {
    return this.service.create(dto, getRequestUser(req).sub);
  }

  @Patch(':id')
  @RequirePermissions('products.manage')
  update(@Param('id') id: string, @Body() dto: UpdateProductDto, @Req() req: Request) {
    return this.service.update(parseId(id), dto, getRequestUser(req).sub);
  }

  @Delete(':id')
  @RequirePermissions('products.manage')
  deactivate(@Param('id') id: string, @Req() req: Request) {
    return this.service.deactivate(parseId(id), getRequestUser(req).sub);
  }

  @Get(':id/barcodes')
  @RequirePermissions('products.view')
  listBarcodes(@Param('id') id: string) {
    return this.service.listBarcodes(parseId(id));
  }

  @Post(':id/barcodes')
  @RequirePermissions('products.manage')
  addBarcode(@Param('id') id: string, @Body() dto: AddBarcodeDto, @Req() req: Request) {
    return this.service.addBarcode(parseId(id), dto.barcode, getRequestUser(req).sub);
  }

  @Delete(':id/barcodes/:barcodeId')
  @RequirePermissions('products.manage')
  removeBarcode(@Param('id') id: string, @Param('barcodeId') barcodeId: string, ) {
    return this.service.removeBarcode(parseId(id), parseId(barcodeId));
  }
}

/** مدیریت دسته، برند و واحد (جداول مرجع کالا) */
@Controller('catalog')
export class CatalogController {
  constructor(private prisma: PrismaService) {}

  @Get('categories')
  @RequirePermissions('products.view')
  categories() {
    return this.prisma.category.findMany({ orderBy: { name: 'asc' } });
  }

  @Post('categories')
  @RequirePermissions('products.manage')
  async addCategory(@Body() dto: CatalogItemDto) {
    return this.prisma.category.upsert({ where: { name: dto.name }, update: {}, create: { name: dto.name } });
  }

  @Get('brands')
  @RequirePermissions('products.view')
  brands() {
    return this.prisma.brand.findMany({ orderBy: { name: 'asc' } });
  }

  @Post('brands')
  @RequirePermissions('products.manage')
  async addBrand(@Body() dto: CatalogItemDto) {
    return this.prisma.brand.upsert({ where: { name: dto.name }, update: {}, create: { name: dto.name } });
  }

  @Get('units')
  @RequirePermissions('products.view')
  units() {
    return this.prisma.unit.findMany({ orderBy: { id: 'asc' } });
  }

  @Post('units')
  @RequirePermissions('products.manage')
  async addUnit(@Body() dto: CatalogItemDto) {
    return this.prisma.unit.upsert({ where: { name: dto.name }, update: {}, create: { name: dto.name } });
  }
}
