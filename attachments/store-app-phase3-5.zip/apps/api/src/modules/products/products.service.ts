import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.module';
import { normalizeFa } from '@store/shared';
import { CreateProductDto, UpdateProductDto } from './products.dto';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  private include = { category: true, brand: true, unit: true, barcodes: true };

  /** شناسایی سه‌روشی: بارکد ← کد کالا ← نام کالا */
  async lookup(term: string) {
    const raw = (term ?? '').trim();
    if (!raw) return { matchType: 'NONE' as const, matches: [] as unknown[] };

    // ۱) تطبیق دقیق بارکد (ایندکس یکتا — سریع‌ترین مسیر)
    const bc = await this.prisma.productBarcode.findUnique({
      where: { barcode: raw },
      include: { product: { include: this.include } },
    });
    if (bc) return { matchType: 'BARCODE' as const, product: this.map(bc.product) };

    // ۲) کد کالا — دقیق یا پیشوندی
    const byCode = await this.prisma.product.findFirst({
      where: { OR: [{ productCode: raw }, { productCode: { startsWith: raw } }] },
      include: this.include,
      orderBy: { productCode: 'asc' },
    });
    if (byCode) return { matchType: 'PRODUCT_CODE' as const, product: this.map(byCode) };

    // ۳) نام کالا — نرمال‌سازی فارسی + شباهت trigram
    const norm = normalizeFa(raw);
    const idRows = await this.prisma.$queryRaw<{ id: bigint }[]>`
      SELECT id FROM products
      WHERE name_norm LIKE ${'%' + norm + '%'} OR name_norm % ${norm}
      ORDER BY similarity(name_norm, ${norm}) DESC, id
      LIMIT 20`;
    if (!idRows.length) return { matchType: 'NONE' as const, matches: [] };

    const products = await this.prisma.product.findMany({
      where: { id: { in: idRows.map((r) => r.id) } },
      include: this.include,
    });
    const order = new Map(idRows.map((r, i) => [r.id.toString(), i]));
    products.sort((a, b) => (order.get(a.id.toString()) ?? 0) - (order.get(b.id.toString()) ?? 0));
    return { matchType: 'NAME' as const, matches: products.map((p) => this.map(p)) };
  }

  async list(params: { q?: string; page?: number; limit?: number }) {
    const page = params.page ?? 1;
    const limit = Math.min(params.limit ?? 20, 100);
    const raw = params.q?.trim();
    const norm = raw ? normalizeFa(raw) : null;
    const where = norm
      ? {
          OR: [
            { nameNorm: { contains: norm } },
            { productCode: { contains: raw } },
            { barcodes: { some: { barcode: raw } } },
          ],
        }
      : {};

    const [total, items] = await this.prisma.$transaction([
      this.prisma.product.count({ where }),
      this.prisma.product.findMany({
        where,
        include: this.include,
        orderBy: { id: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
    ]);
    return { total, page, limit, items: items.map((p) => this.map(p)) };
  }

  async get(id: bigint) {
    const p = await this.prisma.product.findUnique({ where: { id }, include: this.include });
    if (!p) throw new NotFoundException('کالا یافت نشد.');
    return this.map(p);
  }

  async create(dto: CreateProductDto, actorId: string) {
    const productCode = await this.resolveProductCode(dto.productCode);
    const nameNorm = normalizeFa(dto.name);
    const barcodes = this.cleanBarcodes(dto.barcodes ?? []);
    await this.assertBarcodesFree(barcodes);

    const product = await this.prisma.$transaction(async (tx) => {
      const p = await tx.product.create({
        data: {
          productCode,
          name: dto.name,
          nameNorm,
          categoryId: dto.categoryId,
          brandId: dto.brandId,
          unitId: dto.unitId ?? 1,
          purchasePrice: dto.purchasePrice ?? 0,
          salePrice: dto.salePrice ?? 0,
          minimumStock: dto.minimumStock ?? 0,
          description: dto.description,
        },
      });
      if (barcodes.length) {
        await tx.productBarcode.createMany({
          data: barcodes.map((b, i) => ({ productId: p.id, barcode: b, isPrimary: i === 0 })),
        });
      }
      return p;
    });

    await this.prisma.auditLog.create({
      data: {
        userId: actorId,
        action: 'PRODUCT_CREATE',
        entityType: 'product',
        entityId: product.id.toString(),
        afterData: { productCode, name: dto.name } as object,
      },
    });
    return this.get(product.id);
  }

  async update(id: bigint, dto: UpdateProductDto, actorId: string) {
    const before = await this.prisma.product.findUnique({ where: { id } });
    if (!before) throw new NotFoundException('کالا یافت نشد.');

    const data: Record<string, unknown> = {};
    if (dto.name !== undefined) {
      data.name = dto.name;
      data.nameNorm = normalizeFa(dto.name);
    }
    if (dto.categoryId !== undefined) data.categoryId = dto.categoryId;
    if (dto.brandId !== undefined) data.brandId = dto.brandId;
    if (dto.unitId !== undefined) data.unitId = dto.unitId;
    if (dto.description !== undefined) data.description = dto.description;
    if (dto.minimumStock !== undefined) data.minimumStock = dto.minimumStock;
    if (dto.status !== undefined) {
      if (!['ACTIVE', 'INACTIVE'].includes(dto.status)) {
        throw new BadRequestException('وضعیت کالا نامعتبر است.');
      }
      data.status = dto.status;
    }

    // تغییر قیمت → ثبت تاریخچه قیمت
    const history: { priceType: string; oldValue: number; newValue: number }[] = [];
    for (const [field, type] of [
      ['purchasePrice', 'PURCHASE'],
      ['salePrice', 'SALE'],
    ] as const) {
      const nv = (dto as Record<string, unknown>)[field];
      if (nv !== undefined) {
        const ov = Number((before as unknown as Record<string, unknown>)[field] ?? 0);
        if (ov !== Number(nv)) {
          history.push({ priceType: type, oldValue: ov, newValue: Number(nv) });
          data[field] = Number(nv);
        }
      }
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      const p = await tx.product.update({
        where: { id },
        data: data as unknown as Prisma.ProductUncheckedUpdateInput,
        include: this.include,
      });
      if (history.length) {
        await tx.priceHistory.createMany({
          data: history.map((h) => ({
            productId: id,
            priceType: h.priceType,
            oldValue: h.oldValue,
            newValue: h.newValue,
            source: 'MANUAL',
            userId: actorId,
          })),
        });
      }
      return p;
    });

    await this.prisma.auditLog.create({
      data: {
        userId: actorId,
        action: history.length ? 'PRODUCT_PRICE_CHANGE' : 'PRODUCT_UPDATE',
        entityType: 'product',
        entityId: id.toString(),
        beforeData: {
          salePrice: Number(before.salePrice),
          purchasePrice: Number(before.purchasePrice),
        } as object,
        afterData: Object.fromEntries(Object.entries(data)) as object,
      },
    });
    return this.map(updated);
  }

  /** حذف واقعی انجام نمی‌شود — فقط غیرفعال‌سازی (طبق قانون پروژه) */
  async deactivate(id: bigint, actorId: string) {
    const p = await this.prisma.product.findUnique({ where: { id } });
    if (!p) throw new NotFoundException('کالا یافت نشد.');
    await this.prisma.product.update({ where: { id }, data: { status: 'INACTIVE' } });
    await this.prisma.auditLog.create({
      data: { userId: actorId, action: 'PRODUCT_DEACTIVATE', entityType: 'product', entityId: id.toString() },
    });
    return { ok: true };
  }

  // ---------- بارکدها ----------

  listBarcodes(productId: bigint) {
    return this.prisma.productBarcode.findMany({
      where: { productId },
      orderBy: [{ isPrimary: 'desc' }, { id: 'asc' }],
    }).then((rows) => rows.map((b) => this.mapBarcode(b)));
  }

  async addBarcode(productId: bigint, barcode: string, actorId: string) {
    const clean = barcode.trim();
    const existsHere = await this.prisma.productBarcode.findFirst({
      where: { productId, barcode: clean },
    });
    if (existsHere) return { ok: true, message_fa: 'این بارکد قبلاً برای همین کالا ثبت شده است.' };
    await this.assertBarcodesFree([clean]);

    const count = await this.prisma.productBarcode.count({ where: { productId } });
    const bc = await this.prisma.productBarcode.create({
      data: { productId, barcode: clean, isPrimary: count === 0 },
    });
    await this.prisma.auditLog.create({
      data: {
        userId: actorId, action: 'BARCODE_ADD', entityType: 'product',
        entityId: productId.toString(), afterData: { barcode: clean } as object,
      },
    });
    return this.mapBarcode(bc);
  }

  async removeBarcode(productId: bigint, barcodeId: bigint) {
    const bc = await this.prisma.productBarcode.findUnique({ where: { id: barcodeId } });
    if (!bc || bc.productId !== productId) throw new NotFoundException('بارکد یافت نشد.');
    await this.prisma.productBarcode.delete({ where: { id: barcodeId } });
    return { ok: true };
  }

  // ---------- ابزارهای داخلی ----------

  /** تولید کد کالا: دستی (یکتا) یا خودکار (بزرگ‌ترین کد عددی + ۱، شروع از 1001) */
  private async resolveProductCode(productCode?: string) {
    const manual = productCode?.trim();
    if (manual) {
      const exists = await this.prisma.product.findUnique({ where: { productCode: manual } });
      if (exists) throw new ConflictException('این کد کالا قبلاً ثبت شده است.');
      return manual;
    }
    const rows = await this.prisma.$queryRaw<{ max_code: string | null }[]>`
      SELECT MAX(NULLIF(regexp_replace(product_code, '[^0-9]', '', 'g'), '')::bigint)::text AS max_code
      FROM products WHERE product_code ~ '[0-9]'`;
    const next = rows[0]?.max_code ? BigInt(rows[0].max_code) + 1n : 1001n;
    return next.toString();
  }

  private cleanBarcodes(list: string[]) {
    const out: string[] = [];
    for (const b of list) {
      const clean = b.trim();
      if (!clean) continue;
      if (!/^[A-Za-z0-9-]{4,64}$/.test(clean)) {
        throw new BadRequestException(`بارکد نامعتبر است: ${clean}`);
      }
      if (!out.includes(clean)) out.push(clean);
    }
    return out;
  }

  private async assertBarcodesFree(barcodes: string[]) {
    if (!barcodes.length) return;
    const taken = await this.prisma.productBarcode.findMany({
      where: { barcode: { in: barcodes } },
      select: { barcode: true },
    });
    if (taken.length) {
      throw new ConflictException(
        `این بارکد(ها) قبلاً برای کالای دیگری ثبت شده است: ${taken.map((t) => t.barcode).join('، ')}`,
      );
    }
  }

  private mapBarcode(b: { id: bigint; barcode: string; isPrimary: boolean }) {
    return { id: Number(b.id), barcode: b.barcode, isPrimary: b.isPrimary };
  }

  private map(p: Record<string, unknown> & {
    id: bigint;
    barcodes?: { id: bigint; barcode: string; isPrimary: boolean }[];
    category?: { name: string } | null;
    brand?: { name: string } | null;
    unit?: { name: string } | null;
  }) {
    return {
      id: Number(p.id),
      productCode: p.productCode,
      name: p.name,
      categoryName: p.category?.name ?? null,
      brandName: p.brand?.name ?? null,
      unitName: p.unit?.name ?? null,
      purchasePrice: Number(p.purchasePrice),
      salePrice: Number(p.salePrice),
      minimumStock: Number(p.minimumStock),
      description: p.description,
      status: p.status,
      createdAt: p.createdAt,
      barcodes: (p.barcodes ?? []).map((b) => this.mapBarcode(b)),
    };
  }
}
