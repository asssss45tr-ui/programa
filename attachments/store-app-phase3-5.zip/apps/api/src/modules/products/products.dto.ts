import { IsArray, IsInt, IsNumber, IsOptional, IsString, MaxLength, MinLength, Min } from 'class-validator';

export class CreateProductDto {
  @IsOptional() @IsString() @MaxLength(40) productCode?: string;
  @IsString() @MinLength(2) @MaxLength(200) name!: string;
  @IsOptional() @IsInt() categoryId?: number;
  @IsOptional() @IsInt() brandId?: number;
  @IsOptional() @IsInt() unitId?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) purchasePrice?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) salePrice?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) minimumStock?: number;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
  @IsOptional() @IsArray() @IsString({ each: true }) @MaxLength(64, { each: true }) barcodes?: string[];
}

export class UpdateProductDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(200) name?: string;
  @IsOptional() @IsInt() categoryId?: number;
  @IsOptional() @IsInt() brandId?: number;
  @IsOptional() @IsInt() unitId?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) purchasePrice?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) salePrice?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) minimumStock?: number;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
  @IsOptional() @IsString() status?: string;
}

export class AddBarcodeDto {
  @IsString() @MinLength(4) @MaxLength(64) barcode!: string;
}

export class CatalogItemDto {
  @IsString() @MinLength(1) @MaxLength(120) name!: string;
}
