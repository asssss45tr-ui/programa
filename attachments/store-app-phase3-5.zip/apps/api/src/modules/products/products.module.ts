import { Module } from '@nestjs/common';
import { ProductsController, CatalogController } from './products.controller';
import { ProductsService } from './products.service';

@Module({
  controllers: [ProductsController, CatalogController],
  providers: [ProductsService],
})
export class ProductsModule {}
