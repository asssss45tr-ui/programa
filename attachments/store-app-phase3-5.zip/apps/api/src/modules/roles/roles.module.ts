import { Module } from '@nestjs/common';
import { RolesController } from './roles.controller';
import { PrismaModule } from '../../prisma/prisma.module';

@Module({
  controllers: [RolesController],
  imports: [PrismaModule],
})
export class RolesModule {}
