import { Body, Controller, Get, Put, Param, ParseIntPipe, Req } from '@nestjs/common';
import { IsArray, IsInt } from 'class-validator';
import { PrismaService } from '../../prisma/prisma.module';
import { RequirePermissions } from '../../common/permissions.decorator';
import { Request } from 'express';

class SetRolePermissionsDto {
  @IsArray() @IsInt({ each: true }) permissionIds!: number[];
}

@Controller('roles')
export class RolesController {
  constructor(private prisma: PrismaService) {}

  @Get()
  @RequirePermissions('users.manage')
  list() {
    return this.prisma.role.findMany({
      include: { rolePermission: { select: { permissionId: true } } },
    });
  }

  @Get('permissions')
  @RequirePermissions('users.manage')
  permissions() {
    return this.prisma.permission.findMany({ orderBy: [{ module: 'asc' }, { id: 'asc' }] });
  }

  @Put(':id/permissions')
  @RequirePermissions('users.manage')
  async setPermissions(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: SetRolePermissionsDto,
    @Req() req: Request,
  ) {
    await this.prisma.rolePermission.deleteMany({ where: { roleId: id } });
    if (dto.permissionIds.length) {
      await this.prisma.rolePermission.createMany({
        data: dto.permissionIds.map((permissionId) => ({ roleId: id, permissionId })),
      });
    }
    const user = (req as any).user;
    await this.prisma.auditLog.create({
      data: {
        userId: user?.sub, action: 'ROLE_PERMISSIONS_CHANGE',
        entityType: 'role', entityId: String(id),
        afterData: dto as any,
      },
    });
    return { ok: true };
  }
}
