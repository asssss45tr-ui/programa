import { Injectable, UnauthorizedException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import * as crypto from 'crypto';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.module';
import { JwtPayload } from '../../common/jwt-auth.guard';

const REFRESH_TTL_DAYS = 7;

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private cfg: ConfigService,
  ) {}

  async login(username: string, password: string, ip?: string) {
    const user = await this.prisma.user.findUnique({
      where: { username },
      include: { role: { include: { rolePermission: { include: { permission: true } } } } },
    });
    if (!user || !user.isActive) {
      throw new UnauthorizedException('نام کاربری یا رمز عبور اشتباه است.');
    }
    const valid = await argon2.verify(user.passwordHash, password);
    if (!valid) {
      throw new UnauthorizedException('نام کاربری یا رمز عبور اشتباه است.');
    }

    const accessToken = await this.signAccessToken(user);
    const { refreshToken } = await this.issueRefreshToken(user.id);

    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    await this.prisma.auditLog.create({
      data: { userId: user.id, action: 'LOGIN', entityType: 'user', entityId: user.id, ip },
    });

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        roleId: user.roleId,
        roleName: user.role.nameFa,
        permissions: user.role.rolePermission.map((rp) => rp.permission.code),
      },
    };
  }

  async refresh(token: string) {
    if (!token) throw new UnauthorizedException('توکن تازه‌سازی وجود ندارد.');
    const record = await this.prisma.refreshToken.findUnique({ where: { tokenHash: this.hashToken(token) } });
    if (!record || record.revokedAt || record.expiresAt < new Date()) {
      throw new UnauthorizedException('نشست منقضی شده است. دوباره وارد شوید.');
    }
    // چرخش توکن: قبلی باطل، توکن جدید صادر می‌شود
    const user = await this.prisma.user.findUnique({
      where: { id: record.userId },
      include: { role: { include: { rolePermission: { include: { permission: true } } } } },
    });
    if (!user || !user.isActive) throw new UnauthorizedException('حساب کاربری غیرفعال است.');

    await this.prisma.refreshToken.update({
      where: { id: record.id },
      data: { revokedAt: new Date() },
    });
    const { refreshToken } = await this.issueRefreshToken(user.id);
    const accessToken = await this.signAccessToken(user);
    return { accessToken, refreshToken };
  }

  async logout(token?: string, userId?: string) {
    if (token) {
      await this.prisma.refreshToken.updateMany({
        where: { tokenHash: this.hashToken(token), userId },
        data: { revokedAt: new Date() },
      });
    }
    return { ok: true };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new BadRequestException('کاربر یافت نشد.');
    const valid = await argon2.verify(user.passwordHash, currentPassword);
    if (!valid) throw new BadRequestException('رمز عبور فعلی اشتباه است.');
    if (currentPassword === newPassword) {
      throw new BadRequestException('رمز جدید باید با رمز فعلی متفاوت باشد.');
    }
    await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash: await argon2.hash(newPassword) },
    });
    // همه نشست‌ها به جز نشست فعلی بهتر است باطل شوند — اینجا همه را می‌بندیم
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    await this.prisma.auditLog.create({
      data: { userId, action: 'PASSWORD_CHANGE', entityType: 'user', entityId: userId },
    });
    return { ok: true };
  }

  private async signAccessToken(user: {
    id: string;
    username: string;
    roleId: number;
    role: { name: string; rolePermission: { permission: { code: string } }[] };
  }) {
    const payload: JwtPayload = {
      sub: user.id,
      username: user.username,
      roleId: user.roleId,
      roleName: user.role.name,
    };
    return this.jwt.signAsync(payload);
  }

  private async issueRefreshToken(userId: string) {
    const refreshToken = crypto.randomBytes(48).toString('hex');
    await this.prisma.refreshToken.create({
      data: {
        userId,
        tokenHash: this.hashToken(refreshToken),
        expiresAt: new Date(Date.now() + REFRESH_TTL_DAYS * 24 * 3600 * 1000),
      },
    });
    return { refreshToken };
  }

  private hashToken(token: string) {
    return crypto.createHash('sha256').update(token).digest('hex');
  }
}
