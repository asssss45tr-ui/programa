import { Body, Controller, Get, HttpCode, Post, Req } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { Request } from 'express';
import { AuthService } from './auth.service';
import { LoginDto, ChangePasswordDto } from './auth.dto';
import { Public } from '../../common/public.decorator';
import { getRequestUser } from '../../common/request-user';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  @Public()
  @Throttle({ auth: { ttl: 60000, limit: 10 } }) // سقف ۱۰ تلاش در دقیقه برای ورود
  @HttpCode(200)
  @Post('login')
  login(@Body() dto: LoginDto, @Req() req: Request) {
    return this.auth.login(dto.username, dto.password, req.ip);
  }

  @Public()
  @HttpCode(200)
  @Post('refresh')
  refresh(@Body('refreshToken') refreshToken?: string) {
    return this.auth.refresh(refreshToken ?? '');
  }

  @HttpCode(200)
  @Post('logout')
  logout(@Body('refreshToken') refreshToken: string | undefined, @Req() req: Request) {
    const user = getRequestUser(req);
    return this.auth.logout(refreshToken, user.sub);
  }

  @HttpCode(200)
  @Post('change-password')
  changePassword(@Body() dto: ChangePasswordDto, @Req() req: Request) {
    const user = getRequestUser(req);
    return this.auth.changePassword(user.sub, dto.currentPassword, dto.newPassword);
  }

  @Get('me')
  me(@Req() req: Request) {
    return getRequestUser(req);
  }
}
