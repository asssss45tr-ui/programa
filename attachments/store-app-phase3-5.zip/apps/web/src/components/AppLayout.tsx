import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/auth';
import { http } from '../lib/http';

/** آیتم‌های منوی پایین — بر اساس دسترسی کاربر فیلتر می‌شوند (فازهای بعدی فعال می‌شوند) */
const NAV_ITEMS = [
  { to: '/', label: 'خانه', icon: '🏠', perm: null, disabled: false },
  { to: '/scan', label: 'اسکن', icon: '📷', perm: 'products.view', disabled: false },
  { to: '/pos', label: 'صندوق', icon: '🛒', perm: 'sales.create', disabled: true },
  { to: '/products', label: 'کالاها', icon: '📦', perm: 'products.view', disabled: false },
  { to: '/inventory', label: 'انبار', icon: '🏬', perm: 'inventory.view', disabled: true },
];

export function AppLayout() {
  const user = useAuthStore((s) => s.user);
  const logoutStore = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      const { refreshToken } = useAuthStore.getState();
      await http.post('/auth/logout', { refreshToken });
    } catch {
      // مهم نیست — خروج محلی انجام می‌شود
    }
    logoutStore();
    navigate('/login', { replace: true });
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-header-title">
          <span className="app-logo">🏪</span>
          <div>
            <div className="app-store-name">مدیریت فروشگاه</div>
            {user && <div className="app-user-name">{user.fullName} — {user.roleName}</div>}
          </div>
        </div>
        <button className="btn-icon" onClick={handleLogout} title="خروج">
          🚪
        </button>
      </header>

      <main className="app-main">
        <Outlet />
      </main>

      <nav className="bottom-nav">
        {NAV_ITEMS.filter((i) => !i.perm || user?.permissions.includes(i.perm)).map((item) =>
          item.disabled ? (
            <span key={item.to} className="bottom-nav-item disabled" aria-disabled>
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
            </span>
          ) : (
            <NavLink
              key={item.to}
              to={item.to}
              end
              className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''}`}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ),
        )}
      </nav>
    </div>
  );
}
