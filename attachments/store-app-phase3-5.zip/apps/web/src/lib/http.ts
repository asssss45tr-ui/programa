import axios from 'axios';
import { useAuthStore } from '../store/auth';

/**
 * کلاینت HTTP با هندل خودکار خطای 401:
 * تلاش برای تازه‌سازی توکن، و در صورت شکام خروج و هدایت به صفحه ورود.
 */
export const http = axios.create({ baseURL: '/api/v1' });

let refreshing: Promise<string | null> | null = null;

http.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

http.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    const status = error.response?.status;
    if (status === 401 && original && !original._retried) {
      original._retried = true;
      refreshing ??= refreshAccessToken();
      const newToken = await refreshing;
      refreshing = null;
      if (newToken) {
        original.headers.Authorization = `Bearer ${newToken}`;
        return http(original);
      }
      useAuthStore.getState().logout();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  },
);

async function refreshAccessToken(): Promise<string | null> {
  try {
    const { refreshToken, setAuth, user } = useAuthStore.getState();
    if (!refreshToken) return null;
    const res = await axios.post('/api/v1/auth/refresh', { refreshToken });
    const { accessToken, refreshToken: newRefresh } = res.data;
    if (user) setAuth({ accessToken, refreshToken: newRefresh, user });
    return accessToken;
  } catch {
    return null;
  }
}

/** استخراج پیام فارسی خطا از پاسخ سرور */
export function errorMessage(error: unknown, fallback = 'خطایی رخ داد. دوباره تلاش کنید.'): string {
  const e = error as { response?: { data?: { message_fa?: string; message?: string } } };
  return e.response?.data?.message_fa || e.response?.data?.message || fallback;
}
