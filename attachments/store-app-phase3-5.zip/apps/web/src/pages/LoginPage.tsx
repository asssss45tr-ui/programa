import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuthStore } from '../store/auth';
import { errorMessage } from '../lib/http';

export function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const setAuth = useAuthStore((s) => s.setAuth);
  const navigate = useNavigate();

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await axios.post('/api/v1/auth/login', { username, password });
      setAuth(res.data);
      navigate('/', { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'ورود ناموفق بود.'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <div className="login-logo">🏪</div>
        <h1 className="login-title">مدیریت فروشگاه</h1>
        <p className="login-subtitle">برای ورود، اطلاعات حساب خود را وارد کنید</p>

        <label className="field">
          <span>نام کاربری</span>
          <input
            type="text"
            inputMode="text"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="مثلاً admin"
            required
            minLength={3}
          />
        </label>

        <label className="field">
          <span>رمز عبور</span>
          <input
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
            minLength={4}
          />
        </label>

        {error && <div className="alert alert-error">{error}</div>}

        <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
          {loading ? 'در حال ورود…' : 'ورود'}
        </button>
      </form>
    </div>
  );
}
