import { useAuthStore } from '../store/auth';

export function HomePage() {
  const user = useAuthStore((s) => s.user);

  return (
    <div className="page">
      <h2 className="page-title">خوش آمدید 👋</h2>
      <p className="page-sub">
        {user ? `${user.fullName} عزیز،` : ''} سیستم با موفقیت راه‌اندازی شده است.
      </p>

      <div className="card-list">
        <div className="card">
          <div className="card-title">وضعیت سیستم</div>
          <div className="card-body">
            هستهٔ احراز هویت فعال است. بخش‌های کالا، انبار، فروش و گزارش‌ها در فازهای بعدی
            اضافه می‌شوند.
          </div>
        </div>
        <div className="card">
          <div className="card-title">دسترسی‌های شما</div>
          <div className="card-body chips">
            {user?.permissions.map((p) => (
              <span key={p} className="chip">{p}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
