import { useEffect, useMemo, useState, FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { http, errorMessage } from '../lib/http';

export interface Product {
  id: number;
  productCode: string;
  name: string;
  categoryName: string | null;
  brandName: string | null;
  unitName: string | null;
  purchasePrice: number;
  salePrice: number;
  minimumStock: number;
  description: string | null;
  status: string;
  barcodes: { id: number; barcode: string; isPrimary: boolean }[];
}

interface ProductsResponse {
  total: number;
  page: number;
  limit: number;
  items: Product[];
}

function toFa(n: number): string {
  return n.toLocaleString('fa-IR');
}

export function ProductsPage() {
  const [data, setData] = useState<ProductsResponse | null>(null);
  const [searchParams] = useSearchParams();
  const initialQ = searchParams.get('q') ?? '';
  const [query, setQuery] = useState(initialQ);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  async function load(q = '') {
    setLoading(true);
    setError(null);
    try {
      const res = await http.get<ProductsResponse>('/products', { params: q ? { q } : {} });
      setData(res.data);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load(initialQ);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onSearch(e: FormEvent) {
    e.preventDefault();
    load(query);
  }

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h2 className="page-title">کالاها</h2>
          {data && <p className="page-sub">{toFa(data.total)} کالا</p>}
        </div>
        <button className="btn btn-primary btn-add" onClick={() => setShowForm(true)}>
          ＋ کالای جدید
        </button>
      </div>

      <form className="search-bar" onSubmit={onSearch}>
        <input
          type="search"
          placeholder="جستجو با نام، کد کالا یا بارکد…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="btn btn-primary" type="submit" aria-label="جستجو">
          🔍
        </button>
      </form>

      {error && <div className="alert alert-error">{error}</div>}
      {loading && <p className="muted">در حال بارگذاری…</p>}

      <div className="card-list">
        {data?.items.map((p) => (
          <div key={p.id} className="card product-card" onClick={() => setShowForm(true)}>
            <div className="product-row">
              <span className="product-code">{p.productCode}</span>
              <span className="product-name">{p.name}</span>
            </div>
            <div className="product-row sub">
              <span>فروش: {toFa(p.salePrice)}</span>
              <span className={p.status === 'ACTIVE' ? 'badge ok' : 'badge off'}>
                {p.status === 'ACTIVE' ? 'فعال' : 'غیرفعال'}
              </span>
            </div>
            {p.barcodes.length > 0 && (
              <div className="barcode-list">
                {p.barcodes.map((b) => (
                  <span key={b.id} className="chip">{b.barcode}</span>
                ))}
              </div>
            )}
          </div>
        ))}
        {data && data.items.length === 0 && !loading && (
          <p className="muted">کالایی یافت نشد. اولین کالا را ثبت کنید.</p>
        )}
      </div>

      {showForm && (
        <ProductFormModal
          onClose={() => setShowForm(false)}
          onSaved={() => {
            setShowForm(false);
            load(query);
          }}
        />
      )}
    </div>
  );
}

export function ProductFormModal({
  initialBarcodes,
  onClose,
  onSaved,
}: {
  initialBarcodes?: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState('');
  const [productCode, setProductCode] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [salePrice, setSalePrice] = useState('');
  const [minimumStock, setMinimumStock] = useState('');
  const [barcodes, setBarcodes] = useState((initialBarcodes ?? []).join('\n'));
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const parsedBarcodes = useMemo(
    () =>
      barcodes
        .split(/[\n,،]+/)
        .map((b) => b.trim())
        .filter(Boolean),
    [barcodes],
  );

  async function submit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      await http.post('/products', {
        name,
        productCode: productCode || undefined,
        purchasePrice: purchasePrice ? Number(purchasePrice) : undefined,
        salePrice: salePrice ? Number(salePrice) : undefined,
        minimumStock: minimumStock ? Number(minimumStock) : undefined,
        barcodes: parsedBarcodes.length ? parsedBarcodes : undefined,
      });
      onSaved();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3 className="modal-title">ثبت کالای جدید</h3>
        <form onSubmit={submit}>
          <label className="field">
            <span>نام کالا *</span>
            <input value={name} onChange={(e) => setName(e.target.value)} required minLength={2} placeholder="مثلاً نوشابه خانواده" />
          </label>
          <label className="field">
            <span>کد کالا (خالی = تولید خودکار)</span>
            <input value={productCode} onChange={(e) => setProductCode(e.target.value)} inputMode="numeric" placeholder="مثلاً 1001" />
          </label>
          <label className="field">
            <span>بارکدها (هر خط یک بارکد — اختیاری)</span>
            <textarea
              value={barcodes}
              onChange={(e) => setBarcodes(e.target.value)}
              rows={2}
              placeholder={'6261234567890\n6261234567891'}
            />
          </label>
          <div className="form-grid">
            <label className="field">
              <span>قیمت خرید</span>
              <input value={purchasePrice} onChange={(e) => setPurchasePrice(e.target.value)} inputMode="numeric" type="number" min="0" />
            </label>
            <label className="field">
              <span>قیمت فروش</span>
              <input value={salePrice} onChange={(e) => setSalePrice(e.target.value)} inputMode="numeric" type="number" min="0" />
            </label>
          </div>
          <label className="field">
            <span>حداقل موجودی (هشدار)</span>
            <input value={minimumStock} onChange={(e) => setMinimumStock(e.target.value)} inputMode="numeric" type="number" min="0" />
          </label>

          {error && <div className="alert alert-error">{error}</div>}

          <div className="modal-actions">
            <button type="button" className="btn" onClick={onClose}>
              انصراف
            </button>
            <button type="submit" className="btn btn-primary" disabled={saving || !name}>
              {saving ? 'در حال ثبت…' : 'ثبت کالا'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
