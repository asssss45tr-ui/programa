import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BrowserMultiFormatReader } from '@zxing/browser';
import type { IScannerControls } from '@zxing/browser';
import { http, errorMessage } from '../lib/http';
import { useAuthStore } from '../store/auth';
import { ProductFormModal } from './ProductsPage';
import type { Product } from './ProductsPage';

interface LookupResponse {
  matchType: 'BARCODE' | 'PRODUCT_CODE' | 'NAME' | 'NONE';
  product?: Product;
  matches?: Product[];
}

export function ScanPage() {
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [manualTerm, setManualTerm] = useState('');
  const [result, setResult] = useState<LookupResponse | null>(null);
  const [scannedCode, setScannedCode] = useState<string | null>(null);
  const [newProductBarcodes, setNewProductBarcodes] = useState<string[] | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const navigate = useNavigate();
  const canManage = useAuthStore((s) => s.user?.permissions.includes('products.manage') ?? false);

  const stop = useCallback(() => {
    controlsRef.current?.stop();
    controlsRef.current = null;
    setScanning(false);
  }, []);

  // خاموش کردن دوربین هنگام خروج از صفحه
  useEffect(() => () => stop(), [stop]);

  async function handleCode(code: string) {
    stop();
    setScannedCode(code);
    setResult(null);
    try {
      const res = await http.get<LookupResponse>('/products/lookup', { params: { term: code } });
      setResult(res.data);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  async function start() {
    setError(null);
    setResult(null);
    setScannedCode(null);
    setScanning(true);
    const reader = new BrowserMultiFormatReader();
    try {
      const controls = await reader.decodeFromVideoDevice(undefined, videoRef.current!, (r) => {
        if (r) void handleCode(r.getText());
      });
      controlsRef.current = controls;
    } catch {
      setError('دسترسی به دوربین داده نشد. از مرورگر اجازه دسترسی بدهید یا بارکد را دستی وارد کنید.');
      setScanning(false);
    }
  }

  async function manualLookup(e: React.FormEvent) {
    e.preventDefault();
    if (!manualTerm.trim()) return;
    await handleCode(manualTerm.trim());
  }

  const product = result?.product ?? result?.matches?.[0];

  return (
    <div className="page">
      <h2 className="page-title">اسکن بارکد</h2>
      <p className="page-sub">بارکد کالا را مقابل دوربین بگیرید — شناسایی خودکار انجام می‌شود.</p>

      <div className="scan-area">
        <video ref={videoRef} className={`scan-video ${scanning ? 'on' : ''}`} muted playsInline />
        {!scanning && <div className="scan-placeholder">📷 دوربین خاموش است</div>}
      </div>

      {!scanning ? (
        <button className="btn btn-primary btn-block" onClick={start}>
          شروع اسکن
        </button>
      ) : (
        <button className="btn btn-block" onClick={stop}>
          توقف اسکن
        </button>
      )}

      <form className="search-bar" onSubmit={manualLookup}>
        <input
          type="text"
          inputMode="numeric"
          dir="ltr"
          placeholder="یا ورود دستی بارکد / کد کالا…"
          value={manualTerm}
          onChange={(e) => setManualTerm(e.target.value)}
        />
        <button className="btn btn-primary" type="submit">جستجو</button>
      </form>

      {error && <div className="alert alert-error">{error}</div>}

      {product && (
        <div className="card scan-result">
          <div className="scan-ok">✅ کالا شناسایی شد</div>
          <div className="scan-row"><b>نام:</b> {product.name}</div>
          <div className="scan-row"><b>کد کالا:</b> {product.productCode}</div>
          {product.barcodes.length > 0 && (
            <div className="scan-row"><b>بارکد:</b> {product.barcodes.map((b) => b.barcode).join('، ')}</div>
          )}
          <div className="scan-row"><b>قیمت فروش:</b> {product.salePrice.toLocaleString('fa-IR')}</div>
        </div>
      )}

      {result && result.matchType === 'NONE' && (
        <div className="card scan-result">
          <div className="scan-none">❌ این بارکد ثبت نشده است.</div>
          {scannedCode && <div className="scan-row" dir="ltr">{scannedCode}</div>}
          <div className="modal-actions">
            <button className="btn" onClick={() => navigate(`/products?q=${encodeURIComponent(scannedCode ?? '')}`)}>
              جستجو
            </button>
            {canManage && (
              <button
                className="btn btn-primary"
                onClick={() => setNewProductBarcodes([scannedCode ?? ''])}
              >
                ثبت کالای جدید
              </button>
            )}
          </div>
        </div>
      )}

      {newProductBarcodes && (
        <ProductFormModal
          initialBarcodes={newProductBarcodes}
          onClose={() => setNewProductBarcodes(null)}
          onSaved={() => {
            setNewProductBarcodes(null);
            if (scannedCode) void handleCode(scannedCode);
          }}
        />
      )}
    </div>
  );
}
